@echo off
setlocal

where winget >nul 2>nul
if errorlevel 1 goto install_msi

echo Installing Eclipse Temurin JDK 11...
winget install --id EclipseAdoptium.Temurin.11.JDK --exact --accept-source-agreements --accept-package-agreements --silent
if errorlevel 1 goto install_msi
goto success

:install_msi
set "MSI_PATH=%TEMP%\temurin-jdk-11-x64.msi"

echo winget is unavailable or could not install Java.
echo Downloading the official Eclipse Temurin JDK 11 installer...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; Invoke-WebRequest -Uri 'https://api.adoptium.net/v3/installer/latest/11/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk' -OutFile '%MSI_PATH%'"
if errorlevel 1 (
    echo ERROR: Could not download the JDK installer. Check the VPS internet connection.
    pause
    exit /b 1
)

if not exist "%MSI_PATH%" (
    echo ERROR: The JDK installer was not downloaded.
    pause
    exit /b 1
)

echo Installing JDK 11. Administrator permissions may be required.
msiexec.exe /i "%MSI_PATH%" /qn /norestart
if errorlevel 1 (
    echo ERROR: JDK installation failed. Run this file as Administrator.
    pause
    exit /b 1
)

del "%MSI_PATH%" >nul 2>nul

:success
echo.
echo JDK 11 installation completed.
echo Open a new command prompt so the updated Java PATH is available.
pause
exit /b 0
